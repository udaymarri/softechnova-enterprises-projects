import React, { useEffect, useRef, useState } from 'react';

interface MenuItemProps {
  name: string;
  description: string;
  price: number;
  image: string;
  isSpecial?: boolean;
  delay?: number;
}

const MenuItem: React.FC<MenuItemProps> = ({ 
  name, 
  description, 
  price, 
  image, 
  isSpecial = false,
  delay = 0
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const itemRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => {
            setIsVisible(true);
          }, delay);
        }
      },
      { threshold: 0.1 }
    );

    if (itemRef.current) {
      observer.observe(itemRef.current);
    }

    return () => {
      if (itemRef.current) {
        observer.unobserve(itemRef.current);
      }
    };
  }, [delay]);

  return (
    <div 
      ref={itemRef} 
      className={`flex gap-4 p-4 rounded-lg transition-all duration-500 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      } ${isSpecial ? 'bg-amber-100 border-l-4 border-amber-700' : 'bg-white hover:shadow-md'}`}
    >
      <div className="w-24 h-24 flex-shrink-0">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-full object-cover rounded-md"
        />
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-semibold">{name}</h3>
          <span className="font-medium text-amber-800">${price.toFixed(2)}</span>
        </div>
        <p className="text-gray-600 text-sm">{description}</p>
        {isSpecial && (
          <span className="inline-block mt-2 text-xs font-semibold bg-amber-700 text-white px-2 py-1 rounded-full">
            Chef's Special
          </span>
        )}
      </div>
    </div>
  );
};

export default MenuItem;