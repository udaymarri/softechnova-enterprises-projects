interface GalleryImage {
  url: string;
  alt: string;
  title: string;
}

export const galleryImages: GalleryImage[] = [
  {
    url: "https://images.pexels.com/photos/67468/pexels-photo-67468.jpeg",
    alt: "Elegant restaurant interior",
    title: "Our Main Dining Room"
  },
  {
    url: "https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg",
    alt: "Gourmet dish presentation",
    title: "Culinary Artistry"
  },
  {
    url: "https://images.pexels.com/photos/1126728/pexels-photo-1126728.jpeg",
    alt: "Chef preparing food in kitchen",
    title: "Behind the Scenes"
  },
  {
    url: "https://images.pexels.com/photos/5379228/pexels-photo-5379228.jpeg",
    alt: "Craft cocktail",
    title: "Signature Cocktails"
  },
  {
    url: "https://images.pexels.com/photos/299410/pexels-photo-299410.jpeg",
    alt: "Dessert presentation",
    title: "Sweet Endings"
  },
  {
    url: "https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg",
    alt: "Private dining area",
    title: "Private Events Space"
  },
  {
    url: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg",
    alt: "Outdoor patio seating",
    title: "Al Fresco Dining"
  },
  {
    url: "https://images.pexels.com/photos/761854/pexels-photo-761854.jpeg",
    alt: "Wine selection",
    title: "Our Cellar Collection"
  },
  {
    url: "https://images.pexels.com/photos/1579739/pexels-photo-1579739.jpeg",
    alt: "Special event setup",
    title: "Celebrations & Events"
  }
];