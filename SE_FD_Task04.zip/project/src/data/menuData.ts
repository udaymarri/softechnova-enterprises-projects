interface MenuItem {
  name: string;
  description: string;
  price: number;
  image: string;
  isSpecial?: boolean;
}

interface MenuData {
  [category: string]: MenuItem[];
}

export const menuData: MenuData = {
  starters: [
    {
      name: "Truffle Arancini",
      description: "Crispy risotto balls infused with black truffle and parmesan cheese, served with truffle aioli",
      price: 14.95,
      image: "https://images.pexels.com/photos/5639411/pexels-photo-5639411.jpeg",
      isSpecial: true
    },
    {
      name: "Tuna Tartare",
      description: "Fresh yellowfin tuna with avocado, citrus, and wasabi served with crispy wontons",
      price: 16.50,
      image: "https://images.pexels.com/photos/5835353/pexels-photo-5835353.jpeg"
    },
    {
      name: "Burrata & Heirloom Tomatoes",
      description: "Creamy burrata cheese with colorful heirloom tomatoes, basil oil, and aged balsamic",
      price: 13.95,
      image: "https://images.pexels.com/photos/7172068/pexels-photo-7172068.jpeg"
    },
    {
      name: "Roasted Bone Marrow",
      description: "Roasted bone marrow with garlic herb crust, pickled shallots and toasted sourdough",
      price: 15.50,
      image: "https://images.pexels.com/photos/3535383/pexels-photo-3535383.jpeg"
    }
  ],
  mains: [
    {
      name: "Herb-Crusted Rack of Lamb",
      description: "Dijon and herb-crusted lamb with roasted fingerling potatoes and mint gremolata",
      price: 36.95,
      image: "https://images.pexels.com/photos/6941001/pexels-photo-6941001.jpeg",
      isSpecial: true
    },
    {
      name: "Pan-Seared Sea Bass",
      description: "Line-caught sea bass with saffron risotto, asparagus, and lemon beurre blanc",
      price: 32.50,
      image: "https://images.pexels.com/photos/3655916/pexels-photo-3655916.jpeg"
    },
    {
      name: "Wild Mushroom Ravioli",
      description: "Handmade ravioli filled with wild mushrooms, truffles, and ricotta in a light cream sauce",
      price: 24.95,
      image: "https://images.pexels.com/photos/2456435/pexels-photo-2456435.jpeg"
    },
    {
      name: "Dry-Aged Ribeye",
      description: "21-day dry-aged ribeye with garlic confit mashed potatoes and red wine reduction",
      price: 42.95,
      image: "https://images.pexels.com/photos/8969237/pexels-photo-8969237.jpeg"
    }
  ],
  desserts: [
    {
      name: "Dark Chocolate Soufflé",
      description: "Warm chocolate soufflé with vanilla bean ice cream and salted caramel (15 min preparation)",
      price: 12.50,
      image: "https://images.pexels.com/photos/2373520/pexels-photo-2373520.jpeg",
      isSpecial: true
    },
    {
      name: "Vanilla Bean Crème Brûlée",
      description: "Classic vanilla custard with a caramelized sugar crust and seasonal berries",
      price: 10.95,
      image: "https://images.pexels.com/photos/3026805/pexels-photo-3026805.jpeg"
    },
    {
      name: "Lemon Tart",
      description: "Tangy lemon curd in a buttery pastry shell with raspberry coulis and candied lemon",
      price: 9.95,
      image: "https://images.pexels.com/photos/6560123/pexels-photo-6560123.jpeg"
    },
    {
      name: "Tiramisu",
      description: "Espresso-soaked ladyfingers layered with mascarpone cream and dusted with cocoa",
      price: 11.50,
      image: "https://images.pexels.com/photos/4051617/pexels-photo-4051617.jpeg"
    }
  ],
  drinks: [
    {
      name: "Signature Old Fashioned",
      description: "House-infused bourbon with bitters, sugar, and orange zest",
      price: 14.00,
      image: "https://images.pexels.com/photos/5379228/pexels-photo-5379228.jpeg"
    },
    {
      name: "Elderflower Spritz",
      description: "St. Germain elderflower liqueur, prosecco, and soda with fresh mint",
      price: 12.50,
      image: "https://images.pexels.com/photos/2531188/pexels-photo-2531188.jpeg"
    },
    {
      name: "Artisanal Wine Selection",
      description: "Carefully curated selection of wines from boutique vineyards (by glass)",
      price: 13.00,
      image: "https://images.pexels.com/photos/1123260/pexels-photo-1123260.jpeg"
    },
    {
      name: "Craft Beer Flight",
      description: "Selection of four local craft beers with tasting notes",
      price: 15.00,
      image: "https://images.pexels.com/photos/1269025/pexels-photo-1269025.jpeg",
      isSpecial: true
    }
  ]
};